 <hr>
 <footer class="main-nav">
    <p class="text-center" style="color:#FFF;padding:10px;font-size:20px;">CMS project - Rihan</p> 
 </footer> <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="includes/js/bootstrap.min.js"></script>
    <script src="includes/js/addComment.js"></script>
  </body>
</html>